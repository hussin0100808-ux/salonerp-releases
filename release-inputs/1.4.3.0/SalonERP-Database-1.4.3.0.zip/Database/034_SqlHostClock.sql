﻿-- SQL-host business clock. This migration changes no existing business timestamps or balances.
-- Registry reads execute ON THE SQL HOST. Never use the desktop machine's timezone.
SET XACT_ABORT ON;
IF CONVERT(int,SERVERPROPERTY('ProductMajorVersion'))<>17 THROW 51997,'SQL Server 2025 is required for this clock update.',1;
IF DB_NAME() IN(N'master',N'model',N'msdb',N'tempdb') OR DB_NAME()<>ISNULL(CONVERT(nvarchar(128),SESSION_CONTEXT(N'SalonERP.Update.TargetDatabase')),N'') THROW 51997,'Explicit matching SalonERP clock update target required.',1;
IF @@TRANCOUNT<>1 THROW 51997,'Run the clock update in one caller-owned transaction.',1;
IF NOT EXISTS(SELECT 1 FROM dbo.AppSchemaState WHERE Id=1 AND SchemaVersion IN(33,34)) THROW 51997,'Schema033 is required before the SQL-host clock update.',1;
DECLARE @lock int;
EXEC @lock=sys.sp_getapplock @Resource=N'SalonERP.SqlHostClock',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=15000;
IF @lock<0 THROW 51997,'SQL clock configuration is busy.',1;

DECLARE @zone nvarchar(128),@source nvarchar(50)=N'SqlHostRegistry',@now datetime2(7)=SYSUTCDATETIME();
BEGIN TRY
 EXEC master.dbo.xp_regread N'HKEY_LOCAL_MACHINE',N'SYSTEM\CurrentControlSet\Control\TimeZoneInformation',N'TimeZoneKeyName',@zone OUTPUT;
END TRY
BEGIN CATCH
 SET @zone=NULL;
END CATCH;
SET @zone=NULLIF(LTRIM(RTRIM(@zone)),N'');
IF @zone IS NULL
BEGIN
 -- A cached SQL timezone is acceptable only when it agrees with the host's current offset.
 SET @zone=CURRENT_TIMEZONE_ID();
 SET @source=N'SqlCurrentTimeZoneVerifiedOffset';
END;
IF NOT EXISTS(SELECT 1 FROM sys.time_zone_info WHERE name=@zone) THROW 51997,N'تعذر تحديد المنطقة الزمنية المسماة لجهاز SQL. يلزم مسؤول الخادم لمراجعتها؛ لم تُغير بيانات البرنامج.',1;
IF DATEPART(TZOFFSET,@now AT TIME ZONE 'UTC' AT TIME ZONE @zone)<>DATEPART(TZOFFSET,SYSDATETIMEOFFSET())
 THROW 51997,N'المنطقة الزمنية لجهاز SQL لا تتفق مع ساعة الخادم. راجعي إعدادات خادم SQL قبل التحديث؛ لا يتم افتراض فرق ساعات ثابت.',1;

IF OBJECT_ID(N'dbo.SqlHostClockConfiguration',N'U') IS NULL
 CREATE TABLE dbo.SqlHostClockConfiguration(
  Id int NOT NULL CONSTRAINT PK_SqlHostClockConfiguration PRIMARY KEY,
  TimeZoneId nvarchar(128) NOT NULL,
  SqlHostName nvarchar(128) NOT NULL,
  ConfigurationSource nvarchar(50) NOT NULL,
  ConfiguredUtc datetime2(7) NOT NULL CONSTRAINT DF_SqlHostClockConfiguration_Utc DEFAULT SYSUTCDATETIME(),
  Version rowversion NOT NULL,
  CONSTRAINT CK_SqlHostClockConfiguration_Id CHECK(Id=1));
IF EXISTS(SELECT 1 FROM dbo.SqlHostClockConfiguration WHERE Id=1 AND TimeZoneId<>@zone)
 THROW 51997,N'تغيرت المنطقة الزمنية المسجلة لجهاز SQL؛ يلزم مراجعتها قبل إعادة التحديث. لم نعد تفسير السجلات تلقائيًا.',1;
IF NOT EXISTS(SELECT 1 FROM dbo.SqlHostClockConfiguration WHERE Id=1)
 INSERT dbo.SqlHostClockConfiguration(Id,TimeZoneId,SqlHostName,ConfigurationSource)
 VALUES(1,@zone,CONVERT(nvarchar(128),SERVERPROPERTY('ComputerNamePhysicalNetBIOS')),@source);

EXEC(N'CREATE OR ALTER FUNCTION dbo.SalonSqlTimeZone()
RETURNS nvarchar(128)
AS
BEGIN
 DECLARE @zone nvarchar(128);
 SELECT @zone=TimeZoneId FROM dbo.SqlHostClockConfiguration WHERE Id=1;
 RETURN @zone;
END');
EXEC(N'CREATE OR ALTER FUNCTION dbo.SalonSqlNow()
RETURNS datetimeoffset(7)
AS
BEGIN
 DECLARE @utc datetime2(7)=SYSUTCDATETIME(),@zone nvarchar(128)=dbo.SalonSqlTimeZone();
 RETURN @utc AT TIME ZONE ''UTC'' AT TIME ZONE @zone;
END');
EXEC(N'CREATE OR ALTER PROCEDURE dbo.SalonValidateSqlClock
AS
BEGIN
 SET NOCOUNT ON;
 DECLARE @zone nvarchar(128)=dbo.SalonSqlTimeZone(),@utc datetime2(7)=SYSUTCDATETIME();
 IF @zone IS NULL OR NOT EXISTS(SELECT 1 FROM sys.time_zone_info WHERE name=@zone)
  THROW 51997,N''إعداد توقيت جهاز SQL مفقود أو غير صالح. طبقي تحديث قاعدة البرنامج على جهاز SQL.'',1;
 IF DATEPART(TZOFFSET,@utc AT TIME ZONE ''UTC'' AT TIME ZONE @zone)<>DATEPART(TZOFFSET,SYSDATETIMEOFFSET())
  THROW 51997,N''توقيت جهاز SQL تغير ولا يطابق المنطقة المسجلة للبرنامج. أوقفت العملية لحين مراجعة توقيت الخادم؛ لم تُعدّل البيانات.'',1;
END');
EXEC dbo.SalonValidateSqlClock;
UPDATE dbo.AppSchemaState SET SchemaVersion=34,AppliedUtc=SYSUTCDATETIME() WHERE Id=1 AND SchemaVersion=33;

﻿-- One-use update authorization; no application, invoice or ledger data is changed.
SET XACT_ABORT ON;
IF DB_NAME() IN(N'master',N'model',N'msdb',N'tempdb')
 OR DB_NAME()<>ISNULL(CONVERT(nvarchar(128),SESSION_CONTEXT(N'SalonERP.Update.TargetDatabase')),N'')
 THROW 51990,'Explicit matching SalonERP update target required.',1;
IF @@TRANCOUNT<>1 THROW 51990,'Run through the reviewed update runner transaction.',1;
IF NOT EXISTS(SELECT 1 FROM dbo.AppSchemaState WHERE Id=1 AND SchemaVersion IN(34,35))
 THROW 51990,'Schema 034 required.',1;
DECLARE @lock int;
EXEC @lock=sys.sp_getapplock @Resource=N'SalonERP.Security',@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=15000;
IF @lock<0 THROW 51990,'Security is busy.',1;
IF OBJECT_ID(N'dbo.UpdateAuthorization',N'U') IS NULL
BEGIN
 CREATE TABLE dbo.UpdateAuthorization(
  AuthorizationId uniqueidentifier NOT NULL PRIMARY KEY,
  TokenHash binary(32) NOT NULL UNIQUE,
  UserId int NOT NULL REFERENCES dbo.UserAccount(UserId),
  BranchId int NOT NULL REFERENCES dbo.Branch(BranchId),
  SecurityStamp uniqueidentifier NOT NULL,
  StageId uniqueidentifier NOT NULL,
  ManifestHash binary(32) NOT NULL,
  TargetPath nvarchar(1024) NOT NULL,
  ParentPid int NOT NULL,
  ParentStartTicks bigint NOT NULL,
  InstalledVersion nvarchar(32) NOT NULL,
  IssuedUtc datetime2(3) NOT NULL,
  ExpiresUtc datetime2(3) NOT NULL,
  ConsumedUtc datetime2(3) NULL,
  CONSTRAINT CK_UpdateAuthorization_Identity CHECK(ParentPid>0 AND ParentStartTicks>0 AND LEN(TargetPath)>0 AND LEN(InstalledVersion)>0),
  CONSTRAINT CK_UpdateAuthorization_Lifetime CHECK(ExpiresUtc>IssuedUtc AND ExpiresUtc<=DATEADD(minute,5,IssuedUtc)),
  CONSTRAINT CK_UpdateAuthorization_Consumed CHECK(ConsumedUtc IS NULL OR ConsumedUtc>=IssuedUtc)
 );
 CREATE INDEX IX_UpdateAuthorization_ActorExpiry ON dbo.UpdateAuthorization(UserId,ExpiresUtc);
END;
UPDATE dbo.AppSchemaState SET SchemaVersion=35,AppliedUtc=SYSUTCDATETIME() WHERE Id=1 AND SchemaVersion=34;
